<?php
// minimal plugin stub