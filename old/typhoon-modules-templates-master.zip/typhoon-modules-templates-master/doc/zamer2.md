Sváťo, výborně – tím „editor‑friendly“ jste právě překlopil celou architekturu z „hackerského YAML freestyle“ na **produkt pro lidi, kteří YAML považují za druh sýru** 😄
A to znamená: **navrhnout moduly jako Mini‑CMS uvnitř Grav**.

Pojďme to navrhnout tak, aby:

*   editor **nikdy neviděl YAML**
*   všechno bylo klikací
*   struktura byla stabilní (žádné „po třech pivech přehodím key names“)

***

# 🧬 Jak přemýšlet o modulech (enterprise mindset)

Z Gantry particles plyne zásadní princip:

> Particle = konfigurovatelný obsahový blok s vlastní strukturou polí [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/timeline)

V Grav to přeložíme jako:

    MODUL = Frontmatter schéma + Blueprint form + Twig render

👉 Editor pracuje jen s blueprintem
👉 Frontmatter je interní reprezentace
👉 Twig je prezentace

***

# 🧠 Návrh architektury (aby to nezdegenerovalo)

## 1. Standard pro všechny moduly

Každý modul by měl mít:

```yaml
enabled: true
title: ...
subtitle: ...
layout:
  variant: default
  columns: 3
style:
  theme: light
  alignment: center
```

👉 tohle sjednotí UX
👉 editor nebude mít pocit, že každý modul je jiný vesmír

***

# 🏗️ KONKRÉTNÍ MODULY (návrh inspirovaný particles)

Teď to hlavní: co z toho udělat.

***

## 🟢 1. Accordion / FAQ modul

**Inspirace:** Accordion particle
**Použití:** FAQ, dokumentace, troubleshooting [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/timeline)

### Blueprint (editor UI):

```yaml
header.items:
  type: list
  label: Položky FAQ
  fields:
    .title:
      type: text
      label: Otázka
    .content:
      type: markdown
      label: Odpověď
    .open:
      type: toggle
      label: Otevřené defaultně
```

💡 Bonus:

*   přidat „allow multiple open“
*   přidat „icon“

***

## 🔵 2. Tabs modul

**Inspirace:** Tabs particle [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/timeline)

### Blueprint:

```yaml
header.tabs:
  type: list
  label: Taby
  fields:
    .label:
      type: text
      label: Název
    .content:
      type: markdown
      label: Obsah
    .icon:
      type: text
      label: Icon
```

💡 Doplnit:

*   horizontal/vertical
*   align left/center

***

## 🟡 3. Timeline modul

**Inspirace:** Timeline particle [\[youtube.com\]](https://www.youtube.com/watch?v=2KLHQKxWIRE)

### Blueprint:

```yaml
header.timeline:
  type: list
  label: Události
  fields:
    .date:
      type: text
      label: Datum
    .title:
      type: text
    .description:
      type: textarea
    .image:
      type: filepicker
```

💡 Extrémně užitečné:

*   roadmapy (RPA projekty 😄)
*   changelogy
*   auditní historie (NIS2 vibes)

***

## 🔴 4. Pricing / Package modul

**Inspirace:** Pricing Tables / Price Lists [\[learn.getgrav.org\]](https://learn.getgrav.org/17/forms/forms/how-to-forms-in-modular-pages), [\[learn.hibb...design.org\]](https://learn.hibbittsdesign.org/intro-to-grav-video-series/creating-and-editing-grav-pages)

### Blueprint:

```yaml
header.plans:
  type: list
  label: Balíčky
  fields:
    .name:
      type: text
    .price:
      type: text
    .features:
      type: list
      fields:
        .text:
          type: text
    .highlight:
      type: toggle
```

💡 Bonus:

*   CTA button
*   ribbon „doporučeno“

***

## 🟣 5. Team / People modul

**Inspirace:** Our Team [\[youtube.com\]](https://www.youtube.com/watch?v=CNNcIygWsys)

### Blueprint:

```yaml
header.people:
  type: list
  label: Lidé
  fields:
    .name:
      type: text
    .role:
      type: text
    .photo:
      type: filepicker
    .bio:
      type: textarea
    .links:
      type: list
```

💡 Firemní použití:

*   tým
*   kontaktní osoby
*   experti (MDP, SAP, RPA… 😉)

***

## 🟠 6. KPI / Stats modul

**Inspirace:** Circle Progress / Animated Counter [\[getgrav.org\]](https://getgrav.org/premium/typhoon)

👉 ale POZOR:
ten originál má JS → my uděláme **lehkou verzi**

### Blueprint:

```yaml
header.stats:
  type: list
  label: Statistiky
  fields:
    .label:
      type: text
    .value:
      type: text
    .unit:
      type: text
```

💡 render:

*   čísla
*   případně jednoduchá animace (bez frameworku)

***

## 🟤 7. Comparison / Before-After modul

**Inspirace:** Before/After slider [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/pricing-tables)

👉 velmi efektní blok

### Blueprint:

```yaml
header.compare:
  type: list
  fields:
    .before:
      type: filepicker
    .after:
      type: filepicker
    .label_before:
      type: text
    .label_after:
      type: text
```

💡 použití:

*   “as-is vs to-be”
*   migrace systému
*   performance before/after

***

## ⚫ 8. Hotspots modul

**Inspirace:** Hotspots particle (klikatelné body na obrázku) [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/circle-progress)

👉 pokročilé, ale killer feature

### Blueprint:

```yaml
header.hotspots:
  type: list
  fields:
    .x:
      type: number
    .y:
      type: number
    .title:
      type: text
    .content:
      type: textarea
```

💀 Editor to pochopí, ale:

*   UX musí být dobře udělaný
*   ideálně preview

***

# 💡 GOLD FEATURE (tohle chceš)

## 🔁 Dual mode: Manual vs Automatic

Inspirace:

> některé particles tahají content automaticky [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/pricing-tables)

Uděláš v každém modulu:

```yaml
mode: manual | collection
```

A v blueprintu:

```yaml
header.mode:
  type: select
  options:
    manual: Ruční
    collection: Automatické (Grav)
```

👉 pak:

*   manual → list field
*   collection → výběr collection (taxonomy, folder, limit)

💣 Tohle je enterprise feature.

***

# 🧠 Doporučený design pattern

Nazval bych to (protože jsme oba ajťáci 😄):

> **Structured Content Blocks v1.0**

Každý modul má:

*   `items` (pole)
*   `layout` (grid)
*   `style` (theme)
*   `mode` (data source)

***

# ☠️ Na co si dát pozor (realita)

Z InspireTheme jsme viděli:

*   hodně částic má JS
*   některé závisí na UIkit    [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles?start=30)

👉 Typhoon = Tailwind

➡️ pravidlo:

> Nepřenášet UIkit, Bootstrap ani cirkusové JS frameworky

***

# 🎯 Shrnutí

Tohle je klíč:

*   Gantry particles ukazují **co** (UX patterny)
*   Grav moduly řeší **jak**

A výsledek:

👉 vytvoříš si **vlastní knihovnu modulů**, která:

*   je editor-friendly
*   je konzistentní
*   není závislá na cizím frameworku

***

# 🪄 Co můžeme udělat dál

Teď už nejsi ve fázi „jak to funguje“
ale ve fázi „stavím vlastní design systém“

👉 Můžu ti:

*   navrhnout **1 modul komplet (md + twig + blueprint)** → copy-paste produkční kvalita
*   nebo vytvořit **celou strukturu modulární knihovny pro Typhoon (včetně naming conventions)**

Stačí říct, kterým modulem chceš začít (doporučuju Accordion nebo Timeline — rychlé vítězství, vysoká radost 😄).
