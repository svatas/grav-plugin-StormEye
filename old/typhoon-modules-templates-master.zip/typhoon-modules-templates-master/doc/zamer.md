Sváťo, tohle je dobrý nápad - **InspireTheme „particles“ jsou v principu katalog hotových obsahových bloků** (a občas i globálních „atomů“) a přesně tyhle vzory se dají převést do Grav modulů (Typhoon modular pages). Jen je potřeba držet v hlavě, že Gantry a Grav to skládají jinak. V Gantry jsou „particles“ **bloky konfigurované v backendu**, od jednoduchého textu až po věci, které si tahají vlastní JS knihovny a dělají animace. [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/news/81-particle-marketplace-for-gantry-5), [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)

Níže jsem prošel stránku s výpisem částic a doprovodnou dokumentaci, a navrhuji, **které typy částic dávají smysl přetavit do Typhoon modulů** a proč. (Interně u vás ve firmě jsem k tomu nenašel žádné materiály - tohle je čistě webový výzkum + návrh.)

***

## Co přesně InspireTheme nabízí (a proč je to pro inspiraci relevantní)

Na stránce InspireTheme je přímo uvedeno, že jde o „particles and atoms“, které fungují napříč Joomla/WordPress/Grav, a že ty, které mají v názvu konkrétní platformu (Joomla/WordPress/Grav), **umí tahat obsah automaticky z platformy**, aby ho uživatel nemusel tvořit ručně. [\[inspiretheme.com\]](https://www.inspiretheme.com/gantry5-particles)

Zároveň tam je dlouhý seznam typů (namátkou): **Accordion, Tabs, Slideshow, Timeline, Pricing Tables, Our Team, Hotspots, Circle Progress, Before/After, Google Maps, OnePage Menu, Cookie Consent, Scroll To Top, Page Preloader, Fixed Header, Headroom.js, ScrollReveal.js, WOW\.js** atd. [\[inspiretheme.com\]](https://www.inspiretheme.com/gantry5-particles)

A v jejich „freebies“ článku je velmi prakticky popsané, co je particle: místo ručního kopírování HTML se „kliká a vyplňuje“ v administraci.   
To je přesně ta inspirace, kterou chcete: **přenést stejný komfort do Grav - frontmatter + blueprinty** (i když technicky je to jiné). [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)

***

## Filtr: co z particles převádět do Grav modulů a co raději ne

V Typhoon modular stránce máte už teď moduly typu **hero, highlights/features, image-block callout, text columns, gallery, contact form** (to je vidět z vašeho skeleton ZIPu).  
Takže dává smysl doplnit hlavně to, co:

1.  je **obsahový blok** (má to data, která editor vyplní), ne „globální behavior“
2.  jde udělat jako **samostatný modul folder** `_něco` v modular stránce (Grav modular pages koncept). [\[01.home.zip \| Txt\]](https://orlenpl-my.sharepoint.com/personal/vits_ug_cz/Documents/Soubory%20aplikace%20Microsoft%20Copilot%20Chat/01.home.zip.txt)
3.  nepotřebuje přitáhnout půl internetu JS frameworků (nebo to jde udělat střídmě)

Naopak „atomy“ typu **UIkit loader, ScrollReveal.js, WOW\.js, Headroom.js, Fixed Header** jsou spíš **globální věci** (layout/behavior webu), které v Grav typicky řešíte na úrovni šablony nebo pluginu, ne jako modul v obsahu. InspireTheme to tak i rámuje jako „atoms“. [\[inspiretheme.com\]](https://www.inspiretheme.com/gantry5-particles)

***

## Top kandidáti na převod do Typhoon modulů (a proč)

### 1) Accordion modul (FAQ / sekce s rozbalováním)

Accordion je v jejich freebies explicitně popsaný jako UIkit Accordion zabalený do particle.   
**Pro Grav/Typhoon**: tohle je ideální obsahový modul: seznam položek `{title, content}`. Implementace v Typhoonu může být čistě HTML `<details>` (bez JS) nebo malý JS. (Tohle je návrh.) [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)

**Frontmatter idea (návrh):**

```yaml
accordion:
  items:
    - title: Otázka 1
      text: Odpověď 1
```

### 2) Tabs modul (přepínatelné panely)

V freebies je „Tabs particle“ popsaný jako UIkit Tabs + Switcher zabalené do particle.   
**Pro Grav/Typhoon**: opět ideální pro landing page (přehled služeb, parametry, srovnání). [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)

**Frontmatter idea (návrh):**

```yaml
tabs:
  items:
    - label: Výkon
      content: "Text..."
    - label: Bezpečnost
      content: "Text..."
```

### 3) Slideshow / Hero Slider modul

„Slideshow particle“ je v freebies přímo uvedený jako UIkit Slideshow v particle.   
Na seznamu je i „Hero Slider“.   
**Pro Typhoon**: už máte hero, ale často chcete „hero se slidery“ nebo carousel pro reference. [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies) [\[inspiretheme.com\]](https://www.inspiretheme.com/gantry5-particles)

Poznámka: v InspireTheme dokumentaci u částic je vidět, že particle balíčky často obsahují **twig + yaml + scss** (např. Timeline, Pricing Tables, Price Lists) a někdy i **js složku** (Circle Progress).   
To je dobrá indicie: některé bloky jsou „čisté“, některé přidávají JS. [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/timeline), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/pricing-tables), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/price-lists), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/circle-progress)

### 4) Timeline modul

Timeline má vlastní dokumentační stránku (typický balík: `timeline.html.twig`, `timeline.yaml`, `_timeline.scss`).   
**Pro Grav/Typhoon**: perfektní pro „milníky projektu“, roadmapy, historii firmy, release timeline (u vás třeba i pro RapidRAW changelogy). [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/timeline)

**Frontmatter idea (návrh):**

```yaml
timeline:
  items:
    - date: 2026-05
      title: Typhoon modulární peklo zkroceno
      text: "..."
```

### 5) Pricing Tables + Price Lists (dva různé typy cenového bloku)

Oboje má samostatnou dokumentaci a typickou strukturu souborů (pricing: `pricing.html.twig`, `pricing.yaml`, `_pricing.scss`; price list analogicky).   
**Pro Typhoon**: i když neprodáváte hosting, cenové tabulky se hodí i pro „balíčky služeb“, SLA úrovně, interní katalog. [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/pricing-tables), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/price-lists)

### 6) Our Team / People modul

„Our Team“ má v dokumentaci poznámku, že vyžaduje „UIkit for Gantry5“ atom.   
A Hotspots také vyžaduje UIkit atom.   
To je dobré varování: InspireTheme částice jsou často navázané na UIkit. V jejich článku o UIkit atomu popisují, že UIkit museli **upravit**, aby se netloukl s Gantry/Nucleus styly (odstranili core HTML styly, balili do dvou souborů apod.).   
**Pro Typhoon**: Typhoon jede Tailwind, takže „kopírovat UIkit“ by byla cesta do pekla (a v pekle už jste byl a bylo tam plno YAML). Tady by dávalo smysl udělat čistý Tailwind modul: karta osoby, fotka, role, odkazy. [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/our-team) [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/hotspots) [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/48-uikit-for-gantry5-atom-and-updated-particles-freebies)

### 7) Google Maps modul

V freebies je „Google Map particle“ explicitně popsaný: zobrazuje Google Map a má hodně voleb pro konfiguraci layoutu.   
**Pro Grav/Typhoon**: dá se udělat modul, který bere `lat/lng` nebo embed URL a vykreslí mapu/iframe. (Návrh.) [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)

### 8) OnePage Menu modul (navigace po sekcích)

V freebies je „OnePage Menu“ popsané: vertikální menu, které sticky/fixed při scrollu a dělá smoothscroll na sekce.   
**Pro Typhoon modular onepage**: to je téměř „missing piece“ - protože modular stránka je přesně „sekce pod sebou“. V Grav navíc existuje on-page menu koncept, který se často používá v onepage scénáři (vy už v `modular.md` máte `onpage_menu: true` v skeletonu). (Tohle poslední je z vašeho ZIPu, ne z webu.) [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)

***

## Speciální kategorie: „Grav“ particles, které tahají obsah automaticky

InspireTheme přímo říká, že particles s „Grav“ v názvu umí **fetchovat platform content automaticky**.   
To je pro Grav moduly super inspirace: místo ručního vyplňování položek uděláte variantu modulu „ručně“ vs „automaticky z kolekce“. [\[inspiretheme.com\]](https://www.inspiretheme.com/gantry5-particles)

Příklad (návrh): modul „Top News (Grav)“ by v Typhoonu mohl mít mód:

*   `mode: manual` → vyplníte list položek ve frontmatteru
*   `mode: collection` → modul si vezme položky z Grav kolekce (např. poslední články)

(Pozn.: tohle je návrhový princip; konkrétní implementace závisí na vašich šablonách a kolekcích.)

***

## Co bych z toho udělal jako první (nejvyšší návratnost)

Kdybych měl doporučit pořadí „získáte hodně muziky za málo YAML“:

1.  **Accordion (FAQ)** [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)
2.  **Tabs** [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)
3.  **Timeline** [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/timeline)
4.  **Pricing Tables / Price Lists** [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/pricing-tables), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/price-lists)
5.  **Our Team / People (Tailwind-only, bez UIkit)** [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/our-team), [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/48-uikit-for-gantry5-atom-and-updated-particles-freebies)
6.  **OnePage Menu** (protože onepage skeleton + sticky/smoothscroll inspirace) [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)
7.  **Google Maps** (pokud máte kontaktní/obočkové stránky) [\[inspiretheme.com\]](https://www.inspiretheme.com/blog/freebies/28-gantry-5-particles-freebies)
8.  „efekty“ typu Hotspots/Circle Progress až nakonec (protože často JS a případné závislosti) [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/hotspots), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/circle-progress)

***

## Krátká technická poznámka k převodu (aby bylo jasné „jak“)

V Gantry je particle typicky dvojice **Twig + YAML** a někdy SCSS/JS (to je vidět opakovaně v jejich instalačních instrukcích).   
V Grav/Typhoon modulu to odpovídá: [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/timeline), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/pricing-tables), [\[inspiretheme.com\]](https://www.inspiretheme.com/documentation/gantry5-particles/circle-progress)

*   `user/pages/.../_module/module.md` (frontmatter data) [\[01.home.zip \| Txt\]](https://orlenpl-my.sharepoint.com/personal/vits_ug_cz/Documents/Soubory%20aplikace%20Microsoft%20Copilot%20Chat/01.home.zip.txt)
*   `templates/modular/module.html.twig` (render)
*   `blueprints/modular/module.yaml` (Admin formulář; tohle je Typhoon/Grav praxe - návrh)
*   případně malé JS v theme assets, pokud fakt musíte

***

## Jedna věc, kterou od vás potřebuji (jen jedna, slibuji)

Chcete z toho udělat:

*   **čistě editor-friendly moduly** (všechno vyklikatelné v Adminu přes blueprinty), nebo
*   **rychlé moduly pro vás jako autora** (frontmatter ručně, blueprint jen minimalisticky)?

Podle toho se výrazně liší návrh „datového kontraktu“ ve frontmatteru (jednoduchý vs robustní).

A ano: v obou případech to jde. Grav je v tomhle flexibilní až podezřele - skoro jako kdyby vás chtěl nalákat do dalšího YAML dobrodružství.
