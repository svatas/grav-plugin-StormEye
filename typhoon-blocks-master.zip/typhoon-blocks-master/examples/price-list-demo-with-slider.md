---
title: Demo Price List (optional slider)
template: modular/price-list-wrap
price_list:
  fill_character: ""
  slider:
    enabled: true
    autoplay: true
    interval: 7
    color: dark
    position: inside
    images:
      - file: header-1.jpg
      - file: header-2.jpg
      - file: header-3.jpg

  sections:
    - title: DINNER
      subtitle: From 5 pm to 11 pm
      items:
        - title: Roast Chicken Salad
          link: /menu/roast-chicken
          price: 20.6
          currency: $
          description: Light and healthy chicken salad

        - title: Lebanese Chicken
          price: 7.80
          currency: $

    - title: DESSERTS
      subtitle: From 5 pm to 11 pm
      items:
        - title: Dark Chocolate Cake
          price: 8.90
          currency: $
          description: Rich chocolate cake

section_classes: py-12
wrapper_classes: max-w-5xl mx-auto px-4 md:px-6
---
