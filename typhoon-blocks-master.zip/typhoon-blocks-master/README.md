# Typhoon Blocks – Price List

Typhoon Blocks – Price List provides **menu‑style price list blocks** for the **Grav Typhoon theme**, inspired by the JoomLead *Price List* particle for Gantry5, but implemented purely with **Grav modular pages**, **Twig** and **Tailwind CSS**.

The block is intended for restaurant menus, service lists, and similar use‑cases where items are displayed with a dotted leader between title and price.

Typhoon itself is **not included** and must be installed separately.

---

## Features

- Menu‑style price list (not a pricing table)
- Section grouping (e.g. DINNER, DESSERTS)
- Title, optional link, price and description per item
- Dotted leader implemented via CSS (responsive, no text hacks)
- Optional image slider (pure JS, no external libraries)
- Full‑width and wrapped layout variants
- Tailwind‑only styling, fully compatible with Typhoon

---

## Requirements

- Grav CMS
- Typhoon Theme (valid license required)

This repository **does not contain** any part of the Typhoon theme.

---

## Installation

Install by copying files into a **Typhoon‑derived custom theme** (recommended and upgrade‑safe).

### File locations

```
templates/modular/
  price-list-full.html.twig
  price-list-wrap.html.twig

templates/partials/
  price-list-items.html.twig
  price-list-slider.html.twig

blueprints/pages/modular/
  price-list-full.yaml
  price-list-wrap.yaml
```

After copying the files:

1. Clear Grav cache
2. In Admin: **Pages → Add → Add Module**
3. Choose **Price List – Full Width** or **Price List – Wrapped**

---

## Slider behaviour

The slider is **optional** and enabled via Frontmatter or Admin UI.

- No external JS or UIkit
- Autoplay on/off
- Interval limited to 5–15 seconds (matching JoomLead behaviour)
- Light / dark control styles
- Images are loaded from the module page media folder

If `price_list.slider.enabled` is `false` or missing, no slider markup or script is rendered.

---

## Example Frontmatter

```yaml
template: modular/price-list-wrap

price_list:
  slider:
    enabled: true
    autoplay: true
    interval: 7
    color: dark
    images:
      - file: header-1.jpg
      - file: header-2.jpg

  sections:
    - title: DINNER
      subtitle: From 5 pm to 11 pm
      items:
        - title: Roast Chicken Salad
          link: /menu/roast-chicken
          price: 20.6
          currency: $
          description: Light and healthy chicken salad

        - title: Lebanese Chicken
          price: 7.80
          currency: $
```

---

## Philosophy

- Uses **standard Grav modular pages**, no new CMS concepts
- “Block” is a UX term, not a technical one
- Pricing logic is content‑driven, not layout‑driven
- Slider is optional and non‑intrusive
- Code is intentionally explicit and easily extensible

---

## Versioning

**v0.2.0**

- Unified file naming for slider and non‑slider variants
- Slider integrated as optional feature
- Single pair of module templates (`price-list-full`, `price-list-wrap`)

---

## License

This project contains only original code created for Typhoon Blocks.

Typhoon Theme is a commercial product by Trilby Media and is **not redistributed** here in any form.
